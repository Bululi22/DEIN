package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Deporte;
import model.Deportista;
import model.Equipo;
import model.Evento;
import model.Olimpiada;
import model.Participacion;

import java.util.Optional;

import dao.DeporteDao;
import dao.DeportistaDao;
import dao.EquipoDao;
import dao.EventoDao;
import dao.OlimpiadaDao;
import dao.ParticipacionDao;
import javafx.event.ActionEvent;

public class OpcionesController {
	@FXML
	private Button btnEditar;
	@FXML
	private Button btnEliminar;

	private String seleccion, texto;
	@SuppressWarnings("unused")
	private Deporte d;
	@SuppressWarnings("unused")
	private Equipo eq;
	@SuppressWarnings("unused")
	private Evento ev;
	@SuppressWarnings("unused")
	private Olimpiada o;
	@SuppressWarnings("unused")
	private Deportista de;
	@SuppressWarnings("unused")
	private Participacion p;

	// Event Listener on Button[#btnEditar].onAction
	@FXML
	public void editarLinea(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Ven" + seleccion + ".fxml"));
			Parent root = loader.load();
			Scene newScene = new Scene(root);
			Stage newStage = new Stage();

			newStage.initModality(Modality.APPLICATION_MODAL);
			newStage.initOwner(this.btnEditar.getScene().getWindow());
			newStage.setResizable(false);
			newStage.setMaximized(false);
			newStage.setScene(newScene);
			newScene.getStylesheets().add(getClass().getResource("/css/application.css").toExternalForm());

			newStage.setTitle("Crear " + seleccion);

			if (seleccion.equals("Equipo")) {
				VenEquipoController control = loader.getController();
				 control.cargarDatos(eq);
			} else if (seleccion.equals("Deporte")) {
				VenDeporteController control = loader.getController();
				control.cargarDatos(d);
			}else if(seleccion.equals("Evento")){
				VenEventoController control = loader.getController();
				control.cargarDatos(ev);
			}else if(seleccion.equals("Olimpiada")){
				VenOlimpiadaController control = loader.getController();
				control.cargarDatos(o);
			}else if(seleccion.equals("Participacion")){
				VenParticipacionController control = loader.getController();
				control.cargarDatos(p);
			}else if(seleccion.equals("Deportista")){
				VenDeportistaController control = loader.getController();
				control.cargarDatos(de);
			}

			newStage.showAndWait();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Event Listener on Button[#btnEliminar].onAction
	@FXML
	public void eliminarLinea(ActionEvent event) {
		try {
			Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
			alert.setHeaderText(null);
			alert.setTitle("Eliminar Linea");
			alert.setContentText("Seguro que quieres eliminar:\n" + texto);
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK) {
				if (seleccion.equals("Equipo")) {
					EquipoDao dao = new EquipoDao();
					dao.borrarEquipo(eq);
				} else if (seleccion.equals("Deporte")) {
					DeporteDao dao = new DeporteDao();
					dao.borrarDeporte(d);
				}else if(seleccion.equals("Evento")){
					EventoDao dao = new EventoDao();
					dao.borrarEvento(ev);
				}else if(seleccion.equals("Olimpiada")){
					OlimpiadaDao dao = new OlimpiadaDao();
					dao.borrarOlimpiada(o);
				}else if(seleccion.equals("Participacion")){
					ParticipacionDao dao = new ParticipacionDao();
					dao.borrarParticipacion(p);
				}else if(seleccion.equals("Deportista")){
					DeportistaDao dao = new DeportistaDao();
					dao.borrarDeportista(de);
				}
				alert.close();
				Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
				alert2.setHeaderText(null);
				alert2.setTitle("Eliminar Linea");
				alert2.setContentText("Linea eliminada");
				alert2.showAndWait();
			}
		} catch (Exception e) {
			e.printStackTrace();
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Error");
			alert.setContentText(e.getMessage());
			alert.showAndWait();
		}

	}

	// Event Listener on Button.onAction
	@FXML
	public void cerrarOpciones(ActionEvent event) {
		Stage stage = (Stage) btnEditar.getScene().getWindow();
		stage.close();
	}

	public void cargarDatos(String seleccion, Deporte c, String s) {
		this.seleccion = seleccion;
		this.d = c;
		this.texto = s;
	}

	public void cargarDatos(String seleccion, Equipo c, String s) {
		this.seleccion = seleccion;
		this.eq = c;
		this.texto = s;
	}

	public void cargarDatos(String seleccion, Evento c, String s) {
		this.seleccion = seleccion;
		this.ev = c;
		this.texto = s;
	}

	public void cargarDatos(String seleccion, Olimpiada c, String s) {
		this.seleccion = seleccion;
		this.o = c;
		this.texto = s;
	}

	public void cargarDatos(String seleccion, Deportista c, String s) {
		this.seleccion = seleccion;
		this.de = c;
		this.texto = s;
	}

	public void cargarDatos(String seleccion, Participacion c, String s) {
		this.seleccion = seleccion;
		this.p = c;
		this.texto = s;
	}
}
