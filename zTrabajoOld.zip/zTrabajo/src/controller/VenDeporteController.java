package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Deporte;
import dao.DeporteDao;
import dao.OlimpiadaDao;
import javafx.event.ActionEvent;

public class VenDeporteController {
	@FXML
	private Label lblTexto;
	@FXML
	private TextField tfNombre;
	@FXML
	private Button btnEjecuta;
	
	private Boolean editar = false;

	@SuppressWarnings("unused")
	private Deporte d;
	
	// Event Listener on Button[#btnEjecuta].onAction
	@FXML
	public void ejecuta(ActionEvent event) {
		String nombre, msg = "";
		
		try {
			DeporteDao dao = new DeporteDao();
			//Crear
			if(!editar) {
				nombre = tfNombre.getText().toString();
				if(!nombre.equals("")) {
					Deporte d = new Deporte(null, nombre);
					dao.crearDeporte(d);
				}else {
					msg = "Campo 'Nombre' no valido";
				}
			}
			//Editar
			else {
				nombre = tfNombre.getText().toString();
				if(!nombre.equals("") && !nombre.equals(d.getNombre())) {
					System.out.println(nombre);
					Deporte de = new Deporte(d.getId_deporte(), nombre);
					dao.editarDeporte(de);
				}else {
					msg = "Campo 'Nombre' no valido";
				}
			}
			if(!msg.equals("")) {
				Alert alert = new Alert(Alert.AlertType.ERROR);
		        alert.setHeaderText(null);
		        alert.setTitle("Error");
		        alert.setContentText(msg);
		        alert.showAndWait();
			}else {
				Alert alert = new Alert(Alert.AlertType.INFORMATION);
		        alert.setHeaderText(null);
		        alert.setTitle("Hecho :)");
		        if(editar) {
		        	alert.setContentText("Editado correctamente");
		        }else {
		        	alert.setContentText("Creado correctamente");
		        }
		        alert.showAndWait();
		        this.cerrar(event);
			}
		}catch (Exception e) {
			e.printStackTrace();
	        Alert alert = new Alert(Alert.AlertType.ERROR);
	        alert.setHeaderText(null);
	        alert.setTitle("Error");
	        alert.setContentText(e.getMessage());
	        alert.showAndWait();
	    }
	}
	// Event Listener on Button.onAction
	@FXML
	public void cerrar(ActionEvent event) {
		Stage stage = (Stage) btnEjecuta.getScene().getWindow();
		stage.close();
	}
	
	public void cargarDatos(Deporte d) {
		this.d=d;
		editar = true;
		lblTexto.setText("EDITAR");
		tfNombre.setText(d.getNombre());
	}
	
}
